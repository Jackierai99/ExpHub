package com.explabs.hub

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.SECONDS).connectTimeout(30, TimeUnit.SECONDS).build()
private val JSON_T = "application/json".toMediaType()
const val DEFAULT_BASE = "https://api.experientiallabs.ai/v1"

class Api(private val key: String, base: String) {
    private val b = base.trim().trimEnd('/')
    private fun rb(path: String) = Request.Builder().url(b + path).header("Authorization", "Bearer $key")
    private fun exec(r: Request): String = http.newCall(r).execute().use { res ->
        val t = res.body?.string() ?: ""
        if (!res.isSuccessful) throw RuntimeException("HTTP ${res.code}: ${t.take(300)}")
        t
    }
    fun models(): List<String> {
        val a = JSONObject(exec(rb("/models").build())).getJSONArray("data")
        return (0 until a.length()).map { a.getJSONObject(it).getString("id") }.sorted()
    }
    fun post(path: String, o: JSONObject) = exec(rb(path).post(o.toString().toRequestBody(JSON_T)).build())
    fun get(path: String) = exec(rb(path).build())
    fun chat(model: String, msgs: List<Pair<String, String>>, onDelta: (String) -> Unit) {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("messages", arr).put("stream", true)
        http.newCall(rb("/chat/completions").post(body.toString().toRequestBody(JSON_T)).build()).execute().use { res ->
            if (!res.isSuccessful) throw RuntimeException("HTTP ${res.code}: ${res.body?.string()?.take(300)}")
            val src = res.body!!.source()
            while (true) {
                val line = src.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val d = line.removePrefix("data:").trim()
                if (d == "[DONE]") break
                val delta = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: continue
                if (!delta.isNull("content")) onDelta(delta.optString("content"))
            }
        }
    }
}

private val IMG = listOf("image", "flux", "imagen", "dall", "sdxl", "stable-diffusion", "seedream", "midjourney", "nano-banana")
private val VID = listOf("video", "veo", "kling", "sora", "wan", "runway", "hailuo", "seedance", "luma", "pika")
private fun isKind(m: String, kw: List<String>) = kw.any { m.contains(it, true) }

private fun urlIn(s: String): String? =
    Regex("\"url\"\\s*:\\s*\"([^\"]+)\"").find(s)?.groupValues?.get(1)?.replace("\\/", "/")
        ?: Regex("https?://[^\"\\s\\\\]+\\.(?:mp4|webm|mov|png|jpg|jpeg|webp)[^\"\\s\\\\]*").find(s)?.value

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF8B5CF6), onPrimary = Color.White,
                background = Color(0xFF0B0B10), surface = Color(0xFF14141C),
                surfaceVariant = Color(0xFF1E1E2A), onSurface = Color(0xFFECECF4), onSurfaceVariant = Color(0xFFECECF4)
            )) { Surface(Modifier.fillMaxSize().systemBarsPadding().imePadding(), color = MaterialTheme.colorScheme.background) { App() } }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var base by remember { mutableStateOf(prefs.getString("base", DEFAULT_BASE) ?: DEFAULT_BASE) }
    var models by remember { mutableStateOf(listOf<String>()) }
    var tab by remember { mutableStateOf(0) }
    var err by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(key.isBlank()) }

    LaunchedEffect(key, base) {
        if (key.isNotBlank()) try {
            models = withContext(Dispatchers.IO) { Api(key, base).models() }; err = ""
        } catch (e: Exception) { err = "Models load nahi hue: ${e.message}" }
    }
    val api = { Api(key, base) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_logo_circle), contentDescription = "logo", modifier = Modifier.size(38.dp))
                Spacer(Modifier.width(10.dp))
                Text("Exp Hub", style = MaterialTheme.typography.titleLarge)
            }
            TextButton(onClick = { settings = true }) { Text("Settings") }
        }
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            listOf("Chat", "Image", "Video").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        if (err.isNotEmpty()) Text(err, color = Color(0xFFFF8A80), modifier = Modifier.padding(12.dp))
        when (tab) {
            0 -> ChatScreen(api, models)
            1 -> GenScreen(false, api, models)
            else -> GenScreen(true, api, models)
        }
    }

    if (settings) {
        var k by remember { mutableStateOf(key) }
        var b by remember { mutableStateOf(base) }
        AlertDialog(onDismissRequest = { if (key.isNotBlank()) settings = false },
            title = { Text("Settings") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(k, { k = it }, label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(b, { b = it }, label = { Text("Base URL") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                key = k.trim(); base = b.trim().ifBlank { DEFAULT_BASE }
                prefs.edit().putString("key", key).putString("base", base).apply(); settings = false
            }) { Text("Save") } })
    }
}

@Composable
fun ModelPicker(models: List<String>, value: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(12.dp)) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(if (value.isBlank()) "Model chuno ▾" else "$value ▾", maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            var q by remember { mutableStateOf("") }
            OutlinedTextField(q, { q = it }, placeholder = { Text("Search / model id likho") }, singleLine = true, modifier = Modifier.padding(8.dp))
            models.filter { it.contains(q, true) }.take(40).forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); open = false }) }
            if (q.isNotBlank()) DropdownMenuItem(text = { Text("Use \"$q\"") }, onClick = { onPick(q); open = false })
        }
    }
}

@Composable
fun Bubble(user: Boolean, text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(shape = RoundedCornerShape(18.dp), color = if (user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp)) {
            SelectionContainer { Text(text.ifEmpty { "…" }, Modifier.padding(12.dp)) }
        }
    }
}

@Composable
fun ChatScreen(api: () -> Api, models: List<String>) {
    val scope = rememberCoroutineScope()
    var model by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Pair<String, String>>() }
    val ls = rememberLazyListState()
    val list = remember(models) { models.filter { !isKind(it, IMG) && !isKind(it, VID) }.ifEmpty { models } }
    LaunchedEffect(msgs.lastOrNull()?.second) { if (msgs.isNotEmpty()) ls.scrollToItem(msgs.lastIndex) }
    Column(Modifier.fillMaxSize()) {
        ModelPicker(list, model) { model = it }
        LazyColumn(Modifier.weight(1f), state = ls, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(msgs) { _, m -> Bubble(m.first == "user", m.second) }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message") }, maxLines = 5)
            Button(enabled = !busy && model.isNotBlank() && input.isNotBlank(), onClick = {
                val text = input; input = ""
                msgs.add("user" to text); msgs.add("assistant" to "")
                val idx = msgs.lastIndex; val hist = msgs.take(idx).toList(); busy = true
                scope.launch(Dispatchers.IO) {
                    var acc = ""
                    try { api().chat(model, hist) { acc += it; msgs[idx] = "assistant" to acc } }
                    catch (e: Exception) { msgs[idx] = "assistant" to (acc + "\n⚠ " + e.message) }
                    busy = false
                }
            }) { Text("Send") }
        }
    }
}

@Composable
fun GenScreen(video: Boolean, api: () -> Api, models: List<String>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var model by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var url by remember { mutableStateOf<String?>(null) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    val list = remember(models) { models.filter { isKind(it, if (video) VID else IMG) }.ifEmpty { models } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ModelPicker(list, model) { model = it }
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            placeholder = { Text(if (video) "Video ka description likho" else "Image ka description likho") }, minLines = 3)
        Button(modifier = Modifier.padding(12.dp), enabled = !busy && model.isNotBlank() && prompt.isNotBlank(), onClick = {
            busy = true; url = null; bmp = null
            status = if (video) "Video ban rahi hai… kuch minute lag sakte hain" else "Image ban rahi hai…"
            scope.launch(Dispatchers.IO) {
                try {
                    val a = api()
                    val body = JSONObject().put("model", model).put("prompt", prompt)
                    if (!video) body.put("n", 1)
                    val resp = a.post(if (video) "/videos/generations" else "/images/generations", body)
                    val b64 = Regex("\"b64_json\"\\s*:\\s*\"([^\"]+)\"").find(resp)?.groupValues?.get(1)
                    if (b64 != null && !video) {
                        val bytes = Base64.decode(b64, Base64.DEFAULT)
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    } else {
                        var u = urlIn(resp)
                        if (u == null) {
                            val id = Regex("\"(?:job_id|id)\"\\s*:\\s*\"([^\"]+)\"").find(resp)?.groupValues?.get(1)
                                ?: throw RuntimeException("Unexpected response: ${resp.take(200)}")
                            repeat(180) {
                                if (u == null) {
                                    delay(5000)
                                    val r = a.get("/jobs/$id")
                                    u = urlIn(r)
                                    if (u == null && r.contains("fail", true)) throw RuntimeException(r.take(200))
                                }
                            }
                        }
                        url = u ?: throw RuntimeException("Timeout")
                    }
                    status = ""
                } catch (e: Exception) { status = "⚠ ${e.message}" }
                busy = false
            }
        }) { Text("Generate") }
        if (status.isNotEmpty()) Text(status, Modifier.padding(horizontal = 12.dp))
        bmp?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.FillWidth) }
        url?.let { u ->
            if (video) AndroidView(factory = { c ->
                VideoView(c).apply {
                    setMediaController(MediaController(c).also { it.setAnchorView(this) })
                    setVideoURI(Uri.parse(u)); setOnPreparedListener { start() }
                }
            }, modifier = Modifier.fillMaxWidth().height(260.dp).padding(12.dp))
            else AsyncImage(model = u, contentDescription = null, modifier = Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.FillWidth)
            OutlinedButton(modifier = Modifier.padding(horizontal = 12.dp), onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }) { Text("Open / Download") }
        }
    }
}
